Extract all files in this zip-archive to the same folder. Then, double-click on the extracted 'api.xml' file to open the API documentation in your browser.
